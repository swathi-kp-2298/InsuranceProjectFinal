package com.infinite.insuranceNew;

public enum Status {
INACTIVE,ACTIVE,LAPSED
}